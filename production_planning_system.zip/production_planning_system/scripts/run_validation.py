#!/usr/bin/env python3
"""Load the monthly workbooks, validate them, print and save the exception report.

    python scripts/run_validation.py
    python scripts/run_validation.py --stages knitting dipping
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from planning.adapters import load_all  # noqa: E402
from planning.quality.joins import join_report  # noqa: E402
from planning.validate import engine, report  # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--stages", nargs="*", default=None, help="subset of stages to load")
    ap.add_argument("--out", type=Path, default=None, help="report output directory")
    args = ap.parse_args()

    ds = load_all(args.stages)
    findings = engine.run(ds)
    joins = join_report(ds)

    print(report.to_console(findings, joins, ds))
    paths = report.write(findings, joins, args.out)
    print(f"\nWritten: {paths['exceptions']}")
    print(f"Written: {paths['joins']}")

    # Non-zero exit when planning is blocked, so CI can gate on it.
    return 1 if engine.planning_blocked(findings) else 0


if __name__ == "__main__":
    raise SystemExit(main())
