#!/usr/bin/env python3
"""Stage 0 gate: print cross-stage join coverage and the unmatched-key backlog.

Exits non-zero while any link is below the configured threshold, so CI can hold
Phase 3 closed until the master data is reconciled.

    python scripts/run_join_report.py
    python scripts/run_join_report.py --backlog
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from planning.adapters import load_all  # noqa: E402
from planning.config import REPORTS_DIR, validation_rules  # noqa: E402
from planning.quality.joins import join_report, unlinked_demand  # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument(
        "--backlog",
        action="store_true",
        help="write the full unmatched-key list for the master data owners",
    )
    args = ap.parse_args()

    ds = load_all()
    joins = join_report(ds)
    threshold = validation_rules()["thresholds"]["min_join_coverage_pct"]

    print(f"STAGE 0 GATE - threshold {threshold}% coverage\n")
    print(joins.to_string(index=False))

    if args.backlog:
        REPORTS_DIR.mkdir(parents=True, exist_ok=True)
        for stage, missing in unlinked_demand(ds).items():
            if missing.empty:
                continue
            path = REPORTS_DIR / f"unlinked_{stage}.csv"
            cols = [
                c
                for c in ("sales_order_item", "material_code", "customer", "remaining_qty")
                if c in missing.columns
            ]
            missing[cols].to_csv(path, index=False)
            print(f"\n{stage}: {len(missing)} unlinked lines -> {path}")

    failed = joins[joins["gate"] == "FAIL"]
    if len(failed):
        print(f"\nGATE FAILED on {len(failed)} of {len(joins)} links.")
        return 1
    print("\nGATE PASSED.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
