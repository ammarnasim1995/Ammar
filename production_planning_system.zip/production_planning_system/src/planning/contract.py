"""The canonical table contract.

Adapters produce raw DataFrames; `conform` forces them onto the shape declared
in config/schema.yaml. Anything undeclared is dropped, so a layout change in a
source workbook cannot leak into planning logic unnoticed.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import pandas as pd

from planning.config import schema


class ContractError(ValueError):
    """A table cannot be conformed to its declared schema."""


def declared_columns(table: str) -> list[str]:
    spec = schema()[table]
    return list(spec.get("required", [])) + list(spec.get("optional", []))


def conform(df: pd.DataFrame, table: str) -> pd.DataFrame:
    """Return `df` reduced and reordered to the declared columns of `table`.

    Missing declared columns are added as null so downstream code can rely on
    their presence. Undeclared columns are dropped.
    """
    spec = schema().get(table)
    if spec is None:
        raise ContractError(f"Unknown table {table!r}; not declared in schema.yaml")

    cols = declared_columns(table)
    out = pd.DataFrame(index=df.index)
    for col in cols:
        out[col] = df[col] if col in df.columns else pd.NA

    dropped = [c for c in df.columns if c not in cols]
    out.attrs["dropped_columns"] = dropped
    out.attrs["table"] = table
    return out.reset_index(drop=True)


@dataclass
class PlanningDataset:
    """The nine canonical tables, plus provenance for the exception report."""

    tables: dict[str, pd.DataFrame] = field(default_factory=dict)
    provenance: dict[str, list[str]] = field(default_factory=dict)

    def add(self, table: str, df: pd.DataFrame, source: str) -> None:
        conformed = conform(df, table)
        if table in self.tables:
            self.tables[table] = pd.concat(
                [self.tables[table], conformed], ignore_index=True
            )
        else:
            self.tables[table] = conformed
        self.provenance.setdefault(table, []).append(source)

    def get(self, table: str) -> pd.DataFrame:
        if table not in self.tables:
            return conform(pd.DataFrame(), table)
        return self.tables[table]

    def summary(self) -> pd.DataFrame:
        rows = [
            {
                "table": name,
                "rows": len(df),
                "sources": ", ".join(self.provenance.get(name, [])),
            }
            for name, df in sorted(self.tables.items())
        ]
        return pd.DataFrame(rows)
