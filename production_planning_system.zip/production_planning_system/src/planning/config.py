"""Paths and YAML config loading.

Mirrors the shape of kpi_system.utils.config so the two packages feel the same.
"""

from __future__ import annotations

import functools
from pathlib import Path
from typing import Any

import yaml

PACKAGE_ROOT = Path(__file__).resolve().parents[2]
CONFIG_DIR = PACKAGE_ROOT / "config"
DATA_DIR = PACKAGE_ROOT / "data"
RAW_DIR = DATA_DIR / "raw"
PROCESSED_DIR = DATA_DIR / "processed"
REPORTS_DIR = DATA_DIR / "reports"


@functools.lru_cache(maxsize=None)
def load_yaml(name: str) -> dict[str, Any]:
    """Load config/<name>.yaml. Cached: config is read-only at runtime."""
    path = CONFIG_DIR / f"{name}.yaml"
    if not path.exists():
        raise FileNotFoundError(f"Config not found: {path}")
    with path.open(encoding="utf-8") as fh:
        return yaml.safe_load(fh)


def schema() -> dict[str, Any]:
    return load_yaml("schema")["tables"]


def sources() -> dict[str, Any]:
    return load_yaml("sources")


def validation_rules() -> dict[str, Any]:
    return load_yaml("validation_rules")


def planning_rules() -> dict[str, Any]:
    return load_yaml("planning_rules")


def uom() -> dict[str, Any]:
    return load_yaml("uom")
