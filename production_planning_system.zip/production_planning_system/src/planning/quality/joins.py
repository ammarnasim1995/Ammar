"""Stage 0 gate: cross-stage join coverage.

The chained MVP (Covering -> Knitting -> Dipping) is only trustworthy if a
demand line at one stage can be resolved to its predecessor. It measures that,
so the gate is a number rather than an opinion.

Finding from Phase 1, preserved here as the reason `normalise` is deliberately
conservative: stripping dashes, case and the KL/AKL suffix variants moved
coverage by 0.0 percentage points on every link. The gaps are genuine missing
master data, not formatting drift, so aggressive normalisation would only
manufacture false matches.
"""

from __future__ import annotations

import re

import pandas as pd

from planning.config import validation_rules
from planning.contract import PlanningDataset

_STRIP = re.compile(r"[\s\-]")


def normalise(code: object) -> str | None:
    """Case- and whitespace-insensitive key. Nothing more (see module docstring)."""
    if code is None or (isinstance(code, float) and pd.isna(code)):
        return None
    text = _STRIP.sub("", str(code)).upper()
    return text or None


def _coverage(left: set, right: set) -> dict:
    left = {x for x in left if x}
    right = {x for x in right if x}
    matched = left & right
    return {
        "left_distinct": len(left),
        "right_distinct": len(right),
        "matched": len(matched),
        "coverage_pct": round(100 * len(matched) / len(left), 1) if left else 0.0,
        "unmatched_examples": ", ".join(sorted(left - right)[:5]),
    }


def _keys(df: pd.DataFrame, stage: str, column: str) -> set:
    sub = df[df["stage"] == stage]
    return {normalise(v) for v in sub[column].dropna()}


def join_report(ds: PlanningDataset) -> pd.DataFrame:
    """Coverage of every cross-stage link the chained plan depends on."""
    demand = ds.get("demand")
    master = ds.get("material_master")
    bom = ds.get("bom")
    routing = ds.get("routing")
    inventory = ds.get("inventory")

    links = []

    def add(name, purpose, left, right):
        row = {"link": name, "purpose": purpose}
        row.update(_coverage(left, right))
        links.append(row)

    add(
        "dipping.material -> knitting.material",
        "Does each dipped FG have a knitting demand line?",
        _keys(demand, "dipping", "material_code"),
        _keys(demand, "knitting", "material_code"),
    )
    add(
        "dipping.order -> knitting.order",
        "Does each dipping sales-order item exist in the knitting plan?",
        _keys(demand, "dipping", "sales_order_item"),
        _keys(demand, "knitting", "sales_order_item"),
    )
    # The authoritative FG master is the knitting workbook's "Master Data" sheet.
    # It must NOT be tested against the union of all material_master rows: each
    # adapter contributes its own plan's materials, so the dipping plan would be
    # validated against itself and always score 100%.
    fg_master = {
        normalise(v)
        for v in master[master["stage"] == "knitting"]["material_code"].dropna()
    }
    add(
        "dipping.fg -> FG master (knitting Master Data)",
        "Is every dipped FG in the authoritative FG master?",
        _keys(demand, "dipping", "material_code"),
        fg_master,
    )
    add(
        "knitting.fg -> FG master (knitting Master Data)",
        "Is every knitted FG in the authoritative FG master?",
        _keys(demand, "knitting", "material_code"),
        fg_master,
    )
    add(
        "liner -> routing",
        "Does every liner in the BOM have a standard time?",
        {normalise(v) for v in bom[bom["level_to"] == "liner"]["component"].dropna()},
        {normalise(v) for v in routing["material_code"].dropna()},
    )
    add(
        "routing.resource -> machine master",
        "Can each routed resource be given a machine count?",
        {normalise(v) for v in routing["resource"].dropna()},
        {
            normalise(v)
            for v in ds.get("resource_master")
            .query("stage == 'knitting'")["resource"]
            .dropna()
        },
    )
    add(
        "covering.material -> knitting.yarn",
        "Is covered yarn consumed by a knitting demand line?",
        _keys(demand, "covering", "material_code"),
        {normalise(v) for v in bom[bom["level_to"] == "yarn"]["component"].dropna()},
    )
    add(
        "knitting.yarn -> yarn stock",
        "Is consumed yarn visible in stock?",
        {normalise(v) for v in bom[bom["level_to"] == "yarn"]["component"].dropna()},
        {normalise(v) for v in inventory["material_code"].dropna()},
    )

    df = pd.DataFrame(links)
    threshold = validation_rules()["thresholds"]["min_join_coverage_pct"]
    df["gate"] = df["coverage_pct"].map(lambda p: "PASS" if p >= threshold else "FAIL")
    return df


def unlinked_demand(ds: PlanningDataset) -> dict[str, pd.DataFrame]:
    """Demand lines with no predecessor-stage match, per stage.

    Per config/planning_rules.yaml these are never dropped and never given an
    invented parent - they are flagged UNLINKED and planned in isolation.
    """
    demand = ds.get("demand")
    out: dict[str, pd.DataFrame] = {}

    predecessor = {"dipping": "knitting", "knitting": "covering"}
    for stage, prev in predecessor.items():
        cur = demand[demand["stage"] == stage].copy()
        if cur.empty:
            continue
        if stage == "dipping":
            prev_keys = _keys(demand, prev, "material_code")
            cur["_k"] = cur["material_code"].map(normalise)
        else:
            # knitting consumes yarn, which covering produces
            prev_keys = _keys(demand, prev, "material_code")
            cur["_k"] = cur["yarn_code"].map(normalise) if "yarn_code" in cur else None
        out[stage] = cur[~cur["_k"].isin(prev_keys)]
    return out


def gate_passed(ds: PlanningDataset) -> bool:
    return bool((join_report(ds)["gate"] == "PASS").all())
