"""Workbook adapters. One module per source workbook.

Every hard-coded sheet name, header row and column letter is declared in
config/sources.yaml, so adapting to next month's file is a config edit.
"""

from __future__ import annotations

from planning.adapters import covering, dipping, knitting
from planning.contract import PlanningDataset

ADAPTERS = {
    "covering": covering,
    "knitting": knitting,
    "dipping": dipping,
}


def load_all(stages: list[str] | None = None) -> PlanningDataset:
    """Load every stage, in predecessor-first order."""
    dataset = PlanningDataset()
    for stage in stages or ["covering", "knitting", "dipping"]:
        ADAPTERS[stage].load(dataset)
    return dataset


__all__ = ["ADAPTERS", "load_all", "covering", "dipping", "knitting"]
