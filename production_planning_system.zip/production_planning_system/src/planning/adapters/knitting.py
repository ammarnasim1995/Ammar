"""Knitting plan adapter (yarn SFG -> liner SFG).

Source layout: 26 sheets, 17 hidden. The four that matter are
  Plan V1       - 626 order lines, header r7, plus three stacked daily grids
  Master Data   - FG -> liner BOM and product attributes
  Receipe Times - 2,555 liner -> resource routings with standard times
  MC            - machine census by gauge and size
  Yarn Stock    - yarn on hand
"""

from __future__ import annotations

from pathlib import Path

import pandas as pd

from planning.adapters import _excel
from planning.config import RAW_DIR, sources
from planning.contract import PlanningDataset

STAGE = "knitting"


def _spec(block: str) -> dict:
    return sources()[STAGE][block]


def _read(path: Path, block: str) -> pd.DataFrame:
    s = _spec(block)
    return _excel.load_sheet(
        path, s["sheet"], s["header_row"], s["first_data_row"], s["columns"]
    )


def plan(path: Path) -> pd.DataFrame:
    df = _read(path, "plan")
    df = df[df["sales_order_item"].notna()].copy()
    # The header row repeats itself inside the data region in this workbook.
    df = df[df["sales_order_item"].astype(str).str.strip() != "Key"]

    key = df["sales_order_item"].astype(str).str.split("/", n=1, expand=True)
    df["sales_order"] = key[0].str.strip()
    df["item"] = key[1].str.strip() if key.shape[1] > 1 else pd.NA

    for col in (
        "order_qty",
        "to_be_shipped",
        "to_be_pack",
        "to_be_dip",
        "to_be_knit",
        "shipped_less_packed",
        "to_be_knit_dp",
        "required_machines",
        "balance_after_plan",
        "excess_stock_paa",
        "consumption_per_1000_paa",
        "output_per_day_per_mc",
    ):
        df[col] = _excel.to_numeric(df[col])

    df["confirmed_delivery_date"] = _excel.to_date(df["confirmed_delivery_date"])
    df["stage"] = STAGE
    return df


def routing(path: Path) -> pd.DataFrame:
    df = _read(path, "routing")
    df = df[df["material_code"].notna()].copy()
    for col in (
        "minutes_per_piece",
        "minutes_per_pair",
        "hours_per_pair",
        "output_per_machine",
        "sum_of_machine",
    ):
        df[col] = _excel.to_numeric(df[col])
    return df


def machines(path: Path) -> pd.DataFrame:
    """Knitting machine census -> one resource per gauge/size combination.

    The MC sheet's right-hand block (cols J-L) is the current availability and
    is authoritative; the left block is a 2024 census kept for reference.
    """
    df = _read(path, "machines")
    df = df[df["machine_count"].notna()].copy()
    df["machine_count"] = _excel.to_numeric(df["machine_count"])

    # Gauge is merged-cell style: stated once then blank for following sizes.
    df["gauge"] = df["gauge"].ffill()
    df = df[df["gauge"].notna() & df["size"].notna()]
    df = df[df["gauge"].astype(str).str.strip().str.lower() != "total"]

    df["resource"] = (
        df["gauge"].astype(str).str.replace(" ", "", regex=False)
        + "-"
        + df["size"].astype(str).str.strip()
    )
    df["stage"] = STAGE
    # Machines-days per day. Hours require the shift pattern, which is not in
    # this workbook (open question 9), so the unit stays explicit.
    df["capacity_per_day"] = df["machine_count"]
    df["capacity_uom"] = "MACHINE_DAY"
    return df.drop_duplicates(subset=["resource"])


def yarn_stock(path: Path) -> pd.DataFrame:
    df = _read(path, "yarn_stock")
    df = df[df["material_code"].notna()].copy()
    # The sheet is a pivot; drop its label and total rows.
    df = df[~df["material_code"].astype(str).str.contains("Total|Row Labels", na=False)]
    df["unrestricted_qty"] = _excel.to_numeric(df["unrestricted_qty"])
    return df.assign(stage=STAGE, uom="KG", storage_location="PIVOT")


def master_data(path: Path) -> pd.DataFrame:
    df = _read(path, "master_data")
    df = df[df["material_code"].notna()].copy()
    return df[df["material_code"].astype(str).str.strip() != "FG Code"]


def load(dataset: PlanningDataset, path: Path | None = None) -> PlanningDataset:
    path = path or RAW_DIR / sources()[STAGE]["file"]
    src = path.name

    df = plan(path)
    demand = df.assign(uom="UNCONFIRMED", remaining_qty=df["to_be_knit"], priority=pd.NA)
    dataset.add("demand", demand, src)

    md = master_data(path)
    dataset.add(
        "material_master",
        md.assign(material_type="FG", stage=STAGE),
        f"{src}:Master Data",
    )

    # Two BOM levels are recoverable from this workbook.
    fg_liner = md[md["liner_code"].notna()][["material_code", "liner_code"]].rename(
        columns={"material_code": "parent", "liner_code": "component"}
    )
    fg_liner = fg_liner.drop_duplicates().assign(
        qty_per=1.0, level_from="fg", level_to="liner", source=f"{src}:Master Data"
    )
    dataset.add("bom", fg_liner, f"{src}:Master Data")

    liner_yarn = df[df["liner_code"].notna() & df["yarn_code"].notna()][
        ["liner_code", "yarn_code", "consumption_per_1000_paa"]
    ].rename(columns={"liner_code": "parent", "yarn_code": "component"})
    liner_yarn = liner_yarn.drop_duplicates(subset=["parent", "component"]).assign(
        # Source states consumption per 1000 PAA; store per unit.
        qty_per=lambda d: _excel.to_numeric(d["consumption_per_1000_paa"]) / 1000.0,
        level_from="liner",
        level_to="yarn",
        source=f"{src}:Plan V1",
    )
    dataset.add("bom", liner_yarn, f"{src}:Plan V1")

    dataset.add("routing", routing(path), f"{src}:Receipe Times")
    dataset.add("resource_master", machines(path), f"{src}:MC")
    dataset.add("inventory", yarn_stock(path), f"{src}:Yarn Stock")

    open_orders = df[df["status"].notna()].assign(remaining_qty=df["to_be_knit"])
    dataset.add("open_orders", open_orders, src)

    return dataset
