"""Shared Excel-reading helpers for the workbook adapters.

The source workbooks are hostile to naive `pd.read_excel`: header rows sit at
r7 / r14 / r31, daily buckets are Excel serial numbers used as column headers,
and 17 of the knitting workbook's 26 sheets are hidden. Everything here exists
to make those quirks explicit rather than accidental.
"""

from __future__ import annotations

import datetime as dt
from pathlib import Path
from typing import Any

import openpyxl
import pandas as pd

# Excel's 1900 date system, with its deliberate leap-year bug: serial 1 is
# 1900-01-01, and serial 60 is the non-existent 1900-02-29. For any serial
# above 60 the offset below is correct.
_EXCEL_EPOCH = dt.date(1899, 12, 30)

# Values Excel lookups leave behind that mean "no value", not a real code.
NULL_TOKENS = {"#N/A", "#REF!", "#VALUE!", "#DIV/0!", "#NAME?", "#NULL!", "#", "", "-"}


def col_to_index(col: str) -> int:
    """'A' -> 1, 'AA' -> 27. Matches what a planner sees in Excel."""
    n = 0
    for ch in col.strip().upper():
        if not ch.isalpha():
            raise ValueError(f"Not a column letter: {col!r}")
        n = n * 26 + (ord(ch) - 64)
    return n


def serial_to_date(value: Any) -> dt.date | None:
    """Convert an Excel date serial to a date. Returns None if not a serial."""
    if isinstance(value, dt.datetime):
        return value.date()
    if isinstance(value, dt.date):
        return value
    try:
        serial = float(value)
    except (TypeError, ValueError):
        return None
    # Plausible window: 2015-01-01 (42005) .. 2035-12-31 (49units). Anything
    # outside is a quantity that happens to be numeric, not a date.
    if not 40000 <= serial <= 60000:
        return None
    return _EXCEL_EPOCH + dt.timedelta(days=int(serial))


def clean(value: Any) -> Any:
    """Normalise a cell: strip whitespace, map Excel error tokens to None."""
    if value is None:
        return None
    if isinstance(value, str):
        stripped = value.strip()
        return None if stripped in NULL_TOKENS else stripped
    return value


def load_sheet(
    path: Path,
    sheet: str,
    header_row: int,
    first_data_row: int,
    columns: dict[str, str],
) -> pd.DataFrame:
    """Read one rectangular block into a DataFrame using explicit column letters.

    `columns` maps canonical name -> Excel column letter. Only those columns are
    read, which is what makes the adapters resilient to columns being inserted
    outside the mapped range.
    """
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    try:
        if sheet not in wb.sheetnames:
            raise KeyError(f"{path.name} has no sheet {sheet!r}. Sheets: {wb.sheetnames}")
        ws = wb[sheet]
        index_map = {name: col_to_index(letter) for name, letter in columns.items()}
        max_col = max(index_map.values())

        records = []
        for row in ws.iter_rows(min_row=first_data_row, max_col=max_col, values_only=True):
            record = {}
            for name, idx in index_map.items():
                record[name] = clean(row[idx - 1]) if idx <= len(row) else None
            if any(v is not None for v in record.values()):
                records.append(record)
    finally:
        wb.close()

    return pd.DataFrame.from_records(records, columns=list(columns))


def read_header_labels(path: Path, sheet: str, header_row: int, max_col: int) -> list[Any]:
    """Return the raw values of a header row, for auditing unlabelled columns."""
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    try:
        ws = wb[sheet]
        for row in ws.iter_rows(
            min_row=header_row, max_row=header_row, max_col=max_col, values_only=True
        ):
            return [clean(v) for v in row]
    finally:
        wb.close()
    return []


def to_numeric(series: pd.Series) -> pd.Series:
    return pd.to_numeric(series, errors="coerce")


def to_date(series: pd.Series) -> pd.Series:
    return series.map(serial_to_date)
