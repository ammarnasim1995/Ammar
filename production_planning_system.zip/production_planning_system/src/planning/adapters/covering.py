"""Yarn Covering plan adapter (raw material -> yarn SFG).

Source layout: single sheet, header at r31, data from r32. Quantities are in
kg - the only stage whose unit of measure is unambiguous in the source.
"""

from __future__ import annotations

from pathlib import Path

import pandas as pd

from planning.adapters import _excel
from planning.config import RAW_DIR, sources
from planning.contract import PlanningDataset

STAGE = "covering"


def plan(path: Path) -> pd.DataFrame:
    spec = sources()[STAGE]["plan"]
    df = _excel.load_sheet(
        path, spec["sheet"], spec["header_row"], spec["first_data_row"], spec["columns"]
    )
    df = df[df["material_code"].notna()].copy()
    df = df[df["material_code"].astype(str).str.strip() != "Material"]

    for col in (
        "order_qty",
        "plan_qty",
        "balance_to_plan",
        "balance_spindle",
        "spindle_output_kg",
        "qty_august",
        "qty_september",
    ):
        df[col] = _excel.to_numeric(df[col])

    df["stage"] = STAGE
    # This plan has no sales order; the material + shipment month is the grain.
    df["sales_order"] = df["customer"].astype(str) + "-" + df["shipment_month"].astype(str)
    df["item"] = df.groupby(["sales_order"]).cumcount().add(1).astype(str)
    return df


def resources(path: Path) -> pd.DataFrame:
    """Covering machines. Capacity is not declared per machine in the source.

    `spindle_output_kg` is a per-line figure, not a machine capacity, so it is
    deliberately NOT promoted to capacity_per_day. The resource is registered
    with null capacity, which validation rule `resource_without_capacity`
    reports as critical rather than the engine assuming a number.
    """
    df = plan(path)
    res = (
        df[df["resource"].notna()][["resource"]]
        .drop_duplicates()
        .assign(
            stage=STAGE,
            capacity_per_day=pd.NA,
            capacity_uom="KG",
            machine_count=1,
        )
    )
    return res


def load(dataset: PlanningDataset, path: Path | None = None) -> PlanningDataset:
    path = path or RAW_DIR / sources()[STAGE]["file"]
    src = path.name
    df = plan(path)

    demand = df.assign(uom="KG", remaining_qty=df["balance_to_plan"], priority=pd.NA)
    dataset.add("demand", demand, src)

    materials = df[["material_code", "type"]].drop_duplicates(subset=["material_code"])
    materials = materials.assign(
        material_type=materials["type"].map(
            lambda t: "FG" if str(t).upper() == "FG" else "SFG"
        ),
        stage=STAGE,
        product_family=materials["type"],
    )
    dataset.add("material_master", materials, src)

    dataset.add("resource_master", resources(path), src)
    dataset.add("open_orders", df.assign(remaining_qty=df["balance_to_plan"]), src)

    return dataset
