"""Dipping / PU plan adapter (liner SFG -> finished good).

Source layout: single sheet, header at r14, data from r15. A small grid at
r2:r6 above the table holds per-line daily capacity and the daily plan.
"""

from __future__ import annotations

from pathlib import Path

import openpyxl
import pandas as pd

from planning.adapters import _excel
from planning.config import RAW_DIR, sources
from planning.contract import PlanningDataset

STAGE = "dipping"


def _plan_frame(path: Path) -> pd.DataFrame:
    spec = sources()[STAGE]["plan"]
    df = _excel.load_sheet(
        path, spec["sheet"], spec["header_row"], spec["first_data_row"], spec["columns"]
    )
    # A row is a real demand line only if it carries the sales-order/item key.
    df = df[df["sales_order_item"].notna()].copy()

    key = df["sales_order_item"].astype(str).str.split("/", n=1, expand=True)
    df["sales_order"] = key[0].str.strip()
    df["item"] = key[1].str.strip() if key.shape[1] > 1 else pd.NA

    for col in (
        "order_qty",
        "to_be_shipped",
        "to_be_knit",
        "to_be_pack",
        "to_be_dip",
        "to_be_dip_with_extra",
        "plan_qty",
        "to_be_planned_qty",
        "liner_stock",
        "liner_shortage",
        "remaining_ctn",
        "ready_ctn",
    ):
        df[col] = _excel.to_numeric(df[col])

    df["confirmed_delivery_date"] = _excel.to_date(df["confirmed_delivery_date"])
    df["stage"] = STAGE
    return df


def line_capacity(path: Path | None = None) -> pd.DataFrame:
    """Per-line daily dipping capacity from the grid above the main table."""
    path = path or RAW_DIR / sources()[STAGE]["file"]
    spec = sources()[STAGE]["line_capacity"]
    cap_idx = _excel.col_to_index(spec["capacity_col"])
    line_idx = _excel.col_to_index(spec["line_col"])

    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    try:
        ws = wb[sources()[STAGE]["plan"]["sheet"]]
        rows = []
        for row in ws.iter_rows(
            min_row=spec["first_data_row"],
            max_row=spec["last_data_row"],
            max_col=max(cap_idx, line_idx),
            values_only=True,
        ):
            capacity = _excel.clean(row[cap_idx - 1])
            line = _excel.clean(row[line_idx - 1])
            if capacity is None or line is None:
                continue
            rows.append(
                {
                    "resource": f"DIP-LINE-{line}",
                    "stage": STAGE,
                    "capacity_per_day": pd.to_numeric(capacity, errors="coerce"),
                    # Blocking question 1: the unit behind this figure is not
                    # declared anywhere in the workbook.
                    "capacity_uom": "UNCONFIRMED",
                    "machine_count": 1,
                    "plant": None,
                }
            )
    finally:
        wb.close()
    return pd.DataFrame(rows)


def load(dataset: PlanningDataset, path: Path | None = None) -> PlanningDataset:
    path = path or RAW_DIR / sources()[STAGE]["file"]
    df = _plan_frame(path)
    src = path.name

    demand = df.assign(uom="UNCONFIRMED", remaining_qty=df["to_be_dip"], priority=pd.NA)
    dataset.add("demand", demand, src)

    # One row per material, not per order line - the plan repeats a material
    # across every sales-order item that asks for it.
    materials = df.assign(
        material_type="FG", stage=STAGE, description=df["material_group_desc"]
    ).drop_duplicates(subset=["material_code"])
    dataset.add("material_master", materials, src)

    # FG -> liner is a genuine one-level BOM link carried on the plan line.
    bom = df[df["liner_code"].notna()][["material_code", "liner_code"]].rename(
        columns={"material_code": "parent", "liner_code": "component"}
    )
    bom = bom.drop_duplicates().assign(
        qty_per=1.0, level_from="fg", level_to="liner", source=src
    )
    dataset.add("bom", bom, src)

    dataset.add("resource_master", line_capacity(path), src)

    stock = df[df["liner_code"].notna()][["liner_code", "liner_stock"]].rename(
        columns={"liner_code": "material_code", "liner_stock": "unrestricted_qty"}
    )
    stock = stock.dropna(subset=["unrestricted_qty"]).drop_duplicates(
        subset=["material_code"]
    )
    stock = stock.assign(stage=STAGE, uom="UNCONFIRMED", storage_location="PLAN")
    dataset.add("inventory", stock, src)

    open_orders = df[df["status"].isin(["LOCK", "CONF"])].assign(
        remaining_qty=df["to_be_dip"]
    )
    dataset.add("open_orders", open_orders, src)

    return dataset
