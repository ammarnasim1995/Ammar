"""Individual data-quality checks.

Each check takes the dataset and its rule spec and returns a list of Finding
rows. Checks never mutate data and never repair it - the whole point is that a
planner sees the problem rather than an engine papering over it.
"""

from __future__ import annotations

import datetime as dt
import re
from dataclasses import asdict, dataclass
from typing import Any, Callable

import pandas as pd

from planning.contract import PlanningDataset

SEVERITY_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3}


@dataclass
class Finding:
    rule_id: str
    severity: str
    table: str
    problem: str
    root_cause: str
    impact: str
    action: str
    owner: str
    count: int
    examples: str

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


CHECKS: dict[str, Callable] = {}


def check(name: str):
    def wrap(fn):
        CHECKS[name] = fn
        return fn

    return wrap


def _examples(values, limit: int = 5) -> str:
    uniq = [str(v) for v in pd.Series(list(values)).dropna().unique()[:limit]]
    return ", ".join(uniq)


def _finding(rule: dict, table: str, count: int, examples: str, **fmt) -> Finding:
    return Finding(
        rule_id=rule["id"],
        severity=rule["severity"],
        table=table,
        problem=rule["problem"].format(table=table, count=count, **fmt),
        root_cause=rule["root_cause"],
        impact=rule["impact"],
        action=rule["action"].format(table=table, **fmt),
        owner=rule.get("owner", "Master Data team"),
        count=count,
        examples=examples,
    )


# --------------------------------------------------------------------------- #
# structural
# --------------------------------------------------------------------------- #


@check("primary_key_unique")
def primary_key_unique(ds: PlanningDataset, rule: dict, schema: dict, cfg: dict):
    out = []
    for table in rule["applies_to"]:
        df = ds.get(table)
        key = schema[table]["key"]
        key = [k for k in key if k in df.columns]
        if df.empty or not key:
            continue
        dupes = df[df.duplicated(subset=key, keep=False)]
        if len(dupes):
            out.append(
                _finding(
                    rule,
                    table,
                    len(dupes),
                    _examples(dupes[key[0]]),
                )
            )
    return out


@check("required_columns_populated")
def required_columns_populated(ds: PlanningDataset, rule: dict, schema: dict, cfg: dict):
    out = []
    for table in rule["applies_to"]:
        df = ds.get(table)
        if df.empty:
            continue
        for col in schema[table].get("required", []):
            if col not in df.columns:
                continue
            missing = df[df[col].isna()]
            if len(missing):
                key = [k for k in schema[table]["key"] if k in df.columns]
                out.append(
                    _finding(
                        rule,
                        table,
                        len(missing),
                        _examples(missing[key[0]]) if key else "",
                        column=col,
                    )
                )
    return out


# --------------------------------------------------------------------------- #
# routing & resources
# --------------------------------------------------------------------------- #


@check("material_mapped_to_multiple_resources")
def material_mapped_to_multiple_resources(ds, rule, schema, cfg):
    df = ds.get("routing")
    if df.empty:
        return []
    counts = df.groupby("material_code")["resource"].nunique()
    bad = counts[counts > 1]
    if bad.empty:
        return []
    return [_finding(rule, "routing", len(bad), _examples(bad.index))]


@check("demanded_material_has_routing")
def demanded_material_has_routing(ds, rule, schema, cfg):
    """Knitting routing is keyed on the LINER code, not the FG code.

    So the correct test is: every liner that a demand line resolves to via the
    BOM must have a routing.
    """
    bom = ds.get("bom")
    routing = ds.get("routing")
    if bom.empty or routing.empty:
        return []
    liners = bom[bom["level_to"] == "liner"]["component"].dropna().unique()
    routed = set(routing["material_code"].dropna())
    missing = [m for m in liners if m not in routed]
    if not missing:
        return []
    return [_finding(rule, "routing", len(missing), _examples(missing))]


@check("positive_cycle_time")
def positive_cycle_time(ds, rule, schema, cfg):
    df = ds.get("routing")
    if df.empty:
        return []
    times = pd.to_numeric(df["minutes_per_piece"], errors="coerce")
    bad = df[times.isna() | (times <= 0)]
    if bad.empty:
        return []
    return [_finding(rule, "routing", len(bad), _examples(bad["material_code"]))]


@check("routed_resource_has_capacity")
def routed_resource_has_capacity(ds, rule, schema, cfg):
    routing = ds.get("routing")
    res = ds.get("resource_master")
    if routing.empty:
        return []
    with_capacity = set(
        res[res["capacity_per_day"].notna()]["resource"].dropna().astype(str)
    )
    routed = set(routing["resource"].dropna().astype(str))
    missing = sorted(routed - with_capacity)
    if not missing:
        return []
    return [_finding(rule, "resource_master", len(missing), _examples(missing))]


# --------------------------------------------------------------------------- #
# BOM
# --------------------------------------------------------------------------- #


@check("fg_has_liner_code")
def fg_has_liner_code(ds, rule, schema, cfg):
    df = ds.get("material_master")
    fg = df[(df["material_type"] == "FG") & (df["stage"] == "knitting")]
    if fg.empty:
        return []
    missing = fg[fg["liner_code"].isna()]
    if missing.empty:
        return []
    return [
        _finding(
            rule, "material_master", len(missing), _examples(missing["material_code"])
        )
    ]


@check("demanded_material_in_master")
def demanded_material_in_master(ds, rule, schema, cfg):
    demand = ds.get("demand")
    master = ds.get("material_master")
    if demand.empty:
        return []
    # Only the knitting workbook's Master Data sheet is the authoritative FG
    # master. Testing against the union would let each plan validate itself,
    # since every adapter contributes its own materials.
    known = set(
        master[master["stage"] == "knitting"]["material_code"].dropna().astype(str)
    )
    out = []
    for stage, grp in demand.groupby("stage"):
        missing = grp[~grp["material_code"].astype(str).isin(known)]
        if len(missing):
            out.append(
                _finding(
                    rule,
                    f"demand[{stage}]",
                    len(missing),
                    _examples(missing["material_code"]),
                )
            )
    return out


# --------------------------------------------------------------------------- #
# demand sanity
# --------------------------------------------------------------------------- #


@check("delivery_date_present")
def delivery_date_present(ds, rule, schema, cfg):
    demand = ds.get("demand")
    if demand.empty:
        return []
    out = []
    for stage, grp in demand.groupby("stage"):
        missing = grp[grp["confirmed_delivery_date"].isna()]
        if len(missing):
            out.append(
                _finding(
                    rule,
                    f"demand[{stage}]",
                    len(missing),
                    _examples(missing["sales_order"]),
                )
            )
    return out


@check("delivery_date_not_in_past")
def delivery_date_not_in_past(ds, rule, schema, cfg, today: dt.date | None = None):
    demand = ds.get("demand")
    if demand.empty:
        return []
    today = today or dt.date.today()

    def _is_past(value) -> bool:
        # The column mixes real dates with NaT and with strings such as
        # "READY"/"Completed" that planners type into date cells. NaT is itself
        # an instance of datetime, so it has to be excluded before comparing.
        if value is None or value is pd.NaT or pd.isna(value):
            return False
        if isinstance(value, dt.datetime):
            return value.date() < today
        if isinstance(value, dt.date):
            return value < today
        return False

    past = demand[demand["confirmed_delivery_date"].map(_is_past)]
    if past.empty:
        return []
    return [_finding(rule, "demand", len(past), _examples(past["sales_order"]))]


@check("quantity_non_negative")
def quantity_non_negative(ds, rule, schema, cfg):
    demand = ds.get("demand")
    if demand.empty:
        return []
    out = []
    for stage, grp in demand.groupby("stage"):
        qty = pd.to_numeric(grp["remaining_qty"], errors="coerce")
        bad = grp[qty < 0]
        if len(bad):
            out.append(
                _finding(
                    rule, f"demand[{stage}]", len(bad), _examples(bad["sales_order"])
                )
            )
    return out


@check("quantity_within_bounds")
def quantity_within_bounds(ds, rule, schema, cfg):
    demand = ds.get("demand")
    if demand.empty:
        return []
    lo = cfg["thresholds"]["quantity_min"]
    hi = cfg["thresholds"]["quantity_max"]
    qty = pd.to_numeric(demand["order_qty"], errors="coerce")
    bad = demand[qty.notna() & ((qty < lo) | (qty > hi))]
    if bad.empty:
        return []
    return [_finding(rule, "demand", len(bad), _examples(bad["sales_order"]))]


# --------------------------------------------------------------------------- #
# coding standards
# --------------------------------------------------------------------------- #

_DASHED = re.compile(r"^[A-Z0-9]+-[A-Z0-9]+$")


@check("consistent_code_format")
def consistent_code_format(ds, rule, schema, cfg):
    """Detect two coding conventions coexisting in the same field."""
    df = ds.get("material_master")
    codes = df["liner_code"].dropna().astype(str)
    if codes.empty:
        return []
    dashed = codes.map(lambda c: bool(_DASHED.match(c)))
    n_dashed, n_plain = int(dashed.sum()), int((~dashed).sum())
    if n_dashed == 0 or n_plain == 0:
        return []
    minority = codes[~dashed] if n_plain < n_dashed else codes[dashed]
    return [
        _finding(
            rule,
            "material_master.liner_code",
            min(n_dashed, n_plain),
            _examples(minority),
        )
    ]


@check("cross_stage_join")
def cross_stage_join(ds, rule, schema, cfg):
    """Report demand lines whose predecessor stage has no matching line."""
    from planning.quality.joins import unlinked_demand

    out = []
    for stage, missing in unlinked_demand(ds).items():
        if not len(missing):
            continue
        out.append(
            _finding(
                rule,
                f"demand[{stage}]",
                len(missing),
                _examples(missing["sales_order_item"]),
            )
        )
    return out


@check("none")
def _noop(ds, rule, schema, cfg):
    """Rules that are recorded for the report but have no automated test."""
    return []
