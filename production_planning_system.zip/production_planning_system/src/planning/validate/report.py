"""Render the exception report for humans and for Power BI."""

from __future__ import annotations

from pathlib import Path

import pandas as pd

from planning.config import REPORTS_DIR
from planning.contract import PlanningDataset
from planning.validate.engine import planning_blocked, severity_counts

RAG = {"critical": "RED", "high": "AMBER", "medium": "AMBER", "low": "GREEN"}


def to_console(report: pd.DataFrame, joins: pd.DataFrame, ds: PlanningDataset) -> str:
    lines: list[str] = []
    add = lines.append

    add("=" * 78)
    add("MIDAS SAFETY - MASTER DATA & DATA QUALITY EXCEPTION REPORT")
    add("=" * 78)

    add("\nDATASET LOADED")
    add(ds.summary().to_string(index=False))

    add("\n\nSTAGE 0 GATE - CROSS-STAGE JOIN COVERAGE")
    add(
        joins[["link", "left_distinct", "matched", "coverage_pct", "gate"]].to_string(
            index=False
        )
    )
    failed = joins[joins["gate"] == "FAIL"]
    if len(failed):
        add(
            f"\n  GATE FAILED on {len(failed)} of {len(joins)} links. Chained "
            "planning cannot be trusted end-to-end until these are reconciled."
        )
        add("  Unmatched examples:")
        for _, row in failed.iterrows():
            add(f"    {row['link']}: {row['unmatched_examples']}")
    else:
        add("\n  GATE PASSED on all links.")

    counts = severity_counts(report)
    add("\n\nEXCEPTION SUMMARY")
    for sev in ("critical", "high", "medium", "low"):
        add(f"  {RAG[sev]:<6} {sev:<9} {counts.get(sev, 0):>4} finding(s)")

    add("\n\nFINDINGS")
    if report.empty:
        add("  None.")
    else:
        for _, r in report.iterrows():
            add("")
            add(f"  [{r['severity'].upper()}] {r['rule_id']} - {r['table']} ({r['count']} rows)")
            add(f"    Problem   : {r['problem']}")
            add(f"    Root cause: {r['root_cause']}")
            add(f"    Impact    : {r['impact']}")
            add(f"    Action    : {r['action']}")
            add(f"    Owner     : {r['owner']}")
            if r["examples"]:
                add(f"    Examples  : {r['examples']}")

    add("\n" + "=" * 78)
    if planning_blocked(report):
        add("PLANNING GATE: BLOCKED - critical findings must be cleared first.")
    else:
        add("PLANNING GATE: OPEN - proceed with risk noted above.")
    add("=" * 78)
    return "\n".join(lines)


def write(report: pd.DataFrame, joins: pd.DataFrame, out_dir: Path | None = None) -> dict[str, Path]:
    out_dir = out_dir or REPORTS_DIR
    out_dir.mkdir(parents=True, exist_ok=True)
    paths = {
        "exceptions": out_dir / "exception_report.csv",
        "joins": out_dir / "join_coverage.csv",
    }
    report.to_csv(paths["exceptions"], index=False)
    joins.to_csv(paths["joins"], index=False)
    return paths
