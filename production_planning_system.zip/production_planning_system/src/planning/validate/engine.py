"""Validation engine.

Runs every rule declared in config/validation_rules.yaml against the canonical
dataset and returns the Master Data & Data Quality Exception Report.

This runs BEFORE any planning. If any critical finding is present, planning is
blocked - the "Garbage In = Garbage Out" principle enforced in code rather than
left to discipline.
"""

from __future__ import annotations

import pandas as pd

from planning.config import schema, validation_rules
from planning.contract import PlanningDataset
from planning.validate.checks import CHECKS, SEVERITY_ORDER, Finding

REPORT_COLUMNS = [
    "severity",
    "rule_id",
    "table",
    "count",
    "problem",
    "root_cause",
    "impact",
    "action",
    "owner",
    "examples",
]


def run(ds: PlanningDataset) -> pd.DataFrame:
    cfg = validation_rules()
    sch = schema()
    default_owner = cfg.get("defaults", {}).get("owner", "Master Data team")

    findings: list[Finding] = []
    for rule in cfg["rules"]:
        rule = {"owner": default_owner, **rule}
        fn = CHECKS.get(rule["check"])
        if fn is None:
            raise KeyError(
                f"Rule {rule['id']!r} references unknown check {rule['check']!r}"
            )
        findings.extend(fn(ds, rule, sch, cfg))

    if not findings:
        return pd.DataFrame(columns=REPORT_COLUMNS)

    df = pd.DataFrame([f.as_dict() for f in findings])
    df["_order"] = df["severity"].map(SEVERITY_ORDER)
    df = df.sort_values(["_order", "count"], ascending=[True, False]).drop(columns="_order")
    return df[REPORT_COLUMNS].reset_index(drop=True)


def severity_counts(report: pd.DataFrame) -> dict[str, int]:
    counts = {s: 0 for s in SEVERITY_ORDER}
    if not report.empty:
        counts.update(report["severity"].value_counts().to_dict())
    return counts


def planning_blocked(report: pd.DataFrame) -> bool:
    """Critical findings block planning."""
    return bool(not report.empty and (report["severity"] == "critical").any())
