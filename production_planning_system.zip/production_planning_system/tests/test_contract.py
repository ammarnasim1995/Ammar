"""Contract and config tests. These need no workbooks."""

from __future__ import annotations

import pandas as pd
import pytest

from planning.config import planning_rules, schema, sources, uom, validation_rules
from planning.contract import ContractError, PlanningDataset, conform, declared_columns
from planning.validate.checks import CHECKS


def test_every_schema_table_declares_a_key():
    for table, spec in schema().items():
        assert spec.get("key"), f"{table} has no primary key"
        for col in spec["key"]:
            assert col in declared_columns(table), (
                f"{table} key column {col!r} is not a declared column"
            )


def test_every_rule_points_at_a_real_check():
    for rule in validation_rules()["rules"]:
        assert rule["check"] in CHECKS, f"{rule['id']} -> unknown check {rule['check']}"


def test_every_rule_has_the_five_report_fields():
    for rule in validation_rules()["rules"]:
        for field in ("problem", "root_cause", "impact", "action"):
            assert rule.get(field), f"{rule['id']} is missing {field}"
        assert rule["severity"] in {"critical", "high", "medium", "low"}


def test_rules_only_apply_to_declared_tables():
    tables = set(schema())
    for rule in validation_rules()["rules"]:
        for table in rule.get("applies_to", []):
            assert table in tables, f"{rule['id']} applies_to unknown table {table!r}"


def test_priority_weights_sum_to_one():
    weights = planning_rules()["priority_score"]["weights"]
    assert round(sum(weights.values()), 6) == 1.0


def test_capacity_is_a_hard_constraint():
    # The brief is explicit: never schedule beyond capacity without marking it.
    assert planning_rules()["capacity"]["allow_overload"] is False
    assert planning_rules()["capacity"]["overload_marker"]


def test_unlinked_lines_are_flagged_not_dropped():
    policy = planning_rules()["unlinked_policy"]["on_missing_predecessor"]
    assert policy == "flag_unlinked_and_plan_in_isolation"


def test_unconfirmed_uom_is_refused_not_guessed():
    # Blocking question 1 - the engine must not invent a conversion.
    assert uom()["unconfirmed_policy"] == "refuse"


def test_sources_declare_a_file_per_stage():
    for stage, spec in sources().items():
        assert spec.get("file"), f"{stage} has no source file declared"
        assert spec.get("plan", {}).get("columns"), f"{stage} declares no plan columns"


def test_conform_drops_undeclared_and_adds_missing():
    df = pd.DataFrame({"material_code": ["A"], "not_in_schema": [1]})
    out = conform(df, "material_master")
    assert "not_in_schema" not in out.columns
    assert "material_type" in out.columns
    assert out.attrs["dropped_columns"] == ["not_in_schema"]


def test_conform_rejects_unknown_table():
    with pytest.raises(ContractError):
        conform(pd.DataFrame(), "no_such_table")


def test_dataset_get_returns_empty_conformed_frame():
    ds = PlanningDataset()
    out = ds.get("routing")
    assert out.empty
    assert list(out.columns) == declared_columns("routing")
