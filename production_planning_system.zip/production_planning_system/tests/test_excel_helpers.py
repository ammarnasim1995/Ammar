"""Unit tests for the Excel quirks the adapters have to absorb."""

from __future__ import annotations

import datetime as dt

import pytest

from planning.adapters._excel import clean, col_to_index, serial_to_date


@pytest.mark.parametrize(
    "letter,expected",
    [("A", 1), ("Z", 26), ("AA", 27), ("AD", 30), ("BE", 57), ("LG", 319)],
)
def test_col_to_index(letter, expected):
    assert col_to_index(letter) == expected


def test_col_to_index_rejects_non_letters():
    with pytest.raises(ValueError):
        col_to_index("A1")


def test_serial_to_date_matches_the_workbook_headers():
    # 46233 is the first bucket in the dipping capacity grid, and the sheet is
    # named "Dipping Plan - July_30" - which is exactly this date. That naming
    # is the independent confirmation that the epoch offset is right.
    assert serial_to_date(46233) == dt.date(2026, 7, 30)
    # 46248 is the first daily bucket in the knitting Plan V1 grid.
    assert serial_to_date(46248) == dt.date(2026, 8, 14)


def test_serial_to_date_ignores_quantities():
    # Order quantities are numeric too; they must not become dates.
    assert serial_to_date(3600) is None
    assert serial_to_date(25200) is None
    assert serial_to_date("READY") is None
    assert serial_to_date(None) is None


def test_serial_to_date_passes_through_real_dates():
    assert serial_to_date(dt.date(2026, 8, 1)) == dt.date(2026, 8, 1)
    assert serial_to_date(dt.datetime(2026, 8, 1, 9, 30)) == dt.date(2026, 8, 1)


@pytest.mark.parametrize("token", ["#N/A", "#REF!", "#DIV/0!", "#", "", "-", "  #N/A  "])
def test_clean_maps_excel_error_tokens_to_none(token):
    assert clean(token) is None


def test_clean_preserves_real_values():
    assert clean("  NH8PUOBKE-01LGIG1 ") == "NH8PUOBKE-01LGIG1"
    assert clean(3600) == 3600
