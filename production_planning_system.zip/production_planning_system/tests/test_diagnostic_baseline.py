"""Integration tests against the August 2026 workbooks.

These pin the Phase 1 diagnostic figures. If a future month's file changes them,
that is a real signal - either the data improved, or an adapter silently broke.

Skipped automatically when data/raw/ is empty, since the workbooks carry
customer names and quantities and are not committed to git.
"""

from __future__ import annotations

import pytest

from planning.adapters import load_all
from planning.config import RAW_DIR, sources
from planning.quality.joins import join_report
from planning.validate import engine

REQUIRED = [spec["file"] for spec in sources().values()]

pytestmark = pytest.mark.skipif(
    not all((RAW_DIR / f).exists() for f in REQUIRED),
    reason="August 2026 workbooks not present in data/raw/",
)


@pytest.fixture(scope="module")
def dataset():
    return load_all()


@pytest.fixture(scope="module")
def report(dataset):
    return engine.run(dataset)


@pytest.fixture(scope="module")
def joins(dataset):
    return join_report(dataset)


# --- adapter row counts ---------------------------------------------------- #


def test_demand_line_counts_per_stage(dataset):
    counts = dataset.get("demand")["stage"].value_counts().to_dict()
    assert counts == {"dipping": 1045, "knitting": 626, "covering": 187}


def test_routing_rows(dataset):
    assert len(dataset.get("routing")) == 2555


def test_routing_is_one_resource_per_material(dataset):
    """Layer 2 question 1: is one SFG mapped to multiple resources? It is not."""
    routing = dataset.get("routing")
    per_material = routing.groupby("material_code")["resource"].nunique()
    assert per_material.max() == 1
    assert len(per_material) == 2555


def test_no_duplicate_order_keys(dataset):
    demand = dataset.get("demand")
    for stage in ("dipping", "knitting"):
        sub = demand[demand["stage"] == stage]
        assert not sub.duplicated(subset=["sales_order", "item"]).any()


# --- Stage 0 join gate ----------------------------------------------------- #


def _coverage(joins, link):
    row = joins[joins["link"] == link]
    assert len(row) == 1, f"link {link!r} not in report"
    return float(row["coverage_pct"].iloc[0])


@pytest.mark.parametrize(
    "link,expected",
    [
        ("dipping.material -> knitting.material", 58.6),
        ("dipping.order -> knitting.order", 48.6),
        ("dipping.fg -> FG master (knitting Master Data)", 84.0),
        ("knitting.fg -> FG master (knitting Master Data)", 77.5),
        ("covering.material -> knitting.yarn", 36.6),
        ("knitting.yarn -> yarn stock", 69.1),
        ("routing.resource -> machine master", 0.0),
    ],
)
def test_join_coverage_matches_diagnostic(joins, link, expected):
    assert _coverage(joins, link) == pytest.approx(expected, abs=0.1)


def test_routing_resources_cannot_be_given_a_machine_count(dataset):
    """Routing codes are PK{gauge}G{brand}{size} (PK13GJXL); the machine census
    is {gauge}GG-{size} (13GG-L). The census carries no brand letter and no XL
    size, so no mapping exists and knitting capacity cannot be computed at all.
    This is the single hardest blocker on rough-cut capacity planning."""
    routing = set(dataset.get("routing")["resource"].dropna())
    machines = set(
        dataset.get("resource_master").query("stage == 'knitting'")["resource"].dropna()
    )
    assert routing and machines
    assert not (routing & machines), "a mapping now exists - update the diagnostic"


def test_stage_0_gate_currently_fails(joins):
    """The chained plan is NOT yet trustworthy. When this test starts failing,
    the master data has been remediated and Phase 3 can be unblocked."""
    assert (joins["gate"] == "FAIL").any()


def test_fg_master_check_is_not_circular(joins, dataset):
    """Each adapter contributes its own materials to material_master. If the FG
    master check ran against that union it would score 100% and prove nothing."""
    assert _coverage(joins, "dipping.fg -> FG master (knitting Master Data)") < 100.0


# --- validation findings --------------------------------------------------- #


def _finding(report, rule_id, table=None):
    sub = report[report["rule_id"] == rule_id]
    if table:
        sub = sub[sub["table"] == table]
    assert len(sub) >= 1, f"expected a {rule_id} finding"
    return sub.iloc[0]


def test_missing_liner_codes_on_fg_master(report):
    assert _finding(report, "fg_without_component")["count"] == 368


def test_covering_has_no_delivery_dates(report):
    assert _finding(report, "missing_delivery_date", "demand[covering]")["count"] == 187


def test_no_multi_resource_routing_finding(report):
    """Routing is clean, so this rule must produce nothing."""
    assert report[report["rule_id"] == "sfg_multi_resource"].empty


def test_zero_cycle_time_rows(report):
    assert _finding(report, "zero_cycle_time")["count"] == 5


def test_mixed_liner_code_conventions_detected(report):
    """Two coding conventions coexist; normalisation does not merge them."""
    assert _finding(report, "mixed_code_convention")["count"] > 0


def test_duplicate_fg_codes(report):
    """Two genuine duplicate FG codes in the knitting Master Data sheet.

    Guards the adapter fix that stopped the dipping plan emitting one master
    row per order line, which had inflated this to 1,484.
    """
    assert _finding(report, "pk_unique", "material_master")["count"] == 4


def test_material_master_is_one_row_per_material_per_stage(dataset):
    master = dataset.get("material_master")
    assert not master.duplicated(subset=["material_code", "stage"]).sum() > 4


def test_planning_is_blocked(report):
    assert engine.planning_blocked(report) is True


def test_every_finding_carries_an_owner_and_action(report):
    assert report["owner"].notna().all()
    assert (report["action"].str.len() > 0).all()
