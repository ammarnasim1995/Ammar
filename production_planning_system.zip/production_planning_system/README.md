# Midas Safety — AI Production Planning & Scheduling

Phases 1 and 2 of the planning automation: a **standardised data contract**, **adapters** for the
three monthly planning workbooks, a **validation engine**, and the **Stage 0 join gate** that
decides whether chained multi-stage planning can be trusted at all.

Planning logic (Phases 3–6) is deliberately **not** built yet. The gate below currently fails, and
building a plan on top of it would produce a confident, wrong answer.

## Why the gate exists

The three stages are planned in three separate workbooks with no shared key discipline. Measured
coverage of the links a chained plan depends on:

| Link | Coverage |
|---|---:|
| **routing.resource → machine master** | **0.0%** |
| covering.material → knitting.yarn | 36.6% |
| dipping.order → knitting.order | 48.6% |
| dipping.material → knitting.material | 58.6% |
| liner → routing | 64.5% |
| knitting.yarn → yarn stock | 69.1% |
| knitting.fg → FG master | 77.5% |
| dipping.fg → FG master | 84.0% |

The 0.0% row is the hardest blocker. `Receipe Times` routes to `PK{gauge}G{brand}{size}`
(`PK13GJXL`), while the `MC` sheet counts machines as `{gauge}GG-{size}` (`13GG-L`). The census
carries no brand letter and no XL size; routing carries no L2/L3. Required knitting load can be
computed from standard times, but there is nothing to divide it by — so capacity utilisation for
knitting cannot be produced at all until a resource mapping exists.

**String normalisation does not fix this.** Stripping dashes, case and the `KL`/`AKL` suffix
variants moves every one of these by 0.0 percentage points. The gaps are genuine missing master
data, so `planning.quality.joins.normalise` stays deliberately conservative — aggressive
normalisation would only manufacture false matches.

## Quick start

```bash
pip install -e ".[dev]"

# Put the monthly workbooks in data/raw/ using the names in config/sources.yaml:
#   knitting_2026_08.xlsx  dipping_2026_08.xlsx  covering_2026_08.xlsx

make validate     # exception report; exits 1 while critical findings exist
make joins        # Stage 0 gate; exits 1 while any link is below threshold
make backlog      # write the unmatched-key list for the master data owners
make test
```

Raw workbooks are **git-ignored** — they carry customer names, quantities and values.

## Layout

```
config/
  schema.yaml            9 canonical tables, each with a declared key
  sources.yaml           every sheet name, header row and column letter
  validation_rules.yaml  rules + severity + Problem/Root Cause/Impact/Action/Owner
  planning_rules.yaml    objective, priority weights, netting, capacity policy
  uom.yaml               unit-of-measure master (blocking question 1)
src/planning/
  contract.py            conforms adapter output to schema.yaml
  adapters/              one module per workbook; _excel.py absorbs the quirks
  validate/              rule engine + exception report
  quality/joins.py       Stage 0 cross-stage join gate
scripts/
  run_validation.py      exception report
  run_join_report.py     Stage 0 gate + unmatched-key backlog
```

**All hard-coded cell references live in `config/sources.yaml`.** When next month's workbook shifts
a header row, edit that file — not Python.

## Design rules the code enforces

- **Garbage In = Garbage Out.** Validation runs before planning. Critical findings return a
  non-zero exit so CI can block.
- **Nothing is dropped silently.** A demand line that cannot be linked to its predecessor is
  flagged `UNLINKED` and planned in isolation — never dropped, never given an invented parent
  (`planning_rules.yaml → unlinked_policy`).
- **No guessed units.** The dipping backlog (4,365,310) against declared line capacity
  (~8,263/day) implies ~528 days, so backlog and capacity are in different units. Until the
  business confirms, `uom.yaml → unconfirmed_policy: refuse` stops the engine converting on a guess.
- **No invented capacity.** Covering machines have no declared per-machine capacity, so they are
  registered with null capacity and reported as a critical finding rather than given a number.
- **Checks cannot validate themselves.** Each adapter contributes its own materials to
  `material_master`, so the FG-master checks run against the knitting `Master Data` sheet only.
  Against the union they would score 100% and prove nothing.

## What blocks Phase 3

Eleven questions, in `docs/open_questions.md`:

0. **Knitting routing codes cannot be joined to the machine census** (0.0%). Blocks knitting
   capacity planning outright.
1. Unit of measure across dipping/knitting vs the capacity grid.
2. Negative "To be Knit" on 462 of 626 knitting lines (73.8%) — real over-production, or a formula defect?
3. Covering `Balance to plan` (127,430 kg) exceeds total `Qty` (97,359 kg).
