# Running registers

Maintained across sessions, per the operating principle: no silent assumptions.

## 1. Blocking questions — Phase 3 cannot start until these are answered

Q0 makes knitting capacity planning impossible outright. Q1–Q3 change the arithmetic itself.

| # | Question | Why it blocks | Owner |
|---|---|---|---|
| 0 | **Knitting resource codes cannot be joined to the machine census — 0.0% coverage.** `Receipe Times` routes to `PK{gauge}G{brand}{size}` (PK13GJXL, PK13GCL, PK15GKM, plus a non-knitting `RW-HH`). The `MC` sheet counts machines as `{gauge}GG-{size}` (13GG-L, 15GG-FT-M). The census carries **no brand letter** (J/C/K) and **no XL size**, while routing carries no L2/L3. Not one of the 21 routed resources resolves to a machine count. | **The hardest blocker.** Rough-cut capacity planning for knitting is impossible: required load can be computed from standard times, but there is nothing to divide it by. Needs a resource mapping table, or one scheme adopted at source. | Industrial Engineering |
| 1 | **Unit of measure.** Are `Order Quantity` / `To be Dip` in pairs, dozens or PAA, and are the dipping line capacities (2,465 / 1,995 / 1,995 / 1,808 per day) in the same unit? A 4,365,310 backlog against ~8,263/day implies ~528 days, which is not credible. Covering is in kg. | Capacity utilisation is meaningless without it. `config/uom.yaml` currently refuses to convert. | Industrial Engineering |
| 2 | **Negative "To be Knit" on 462 of 626 knitting lines (73.8%).** Genuine over-production already banked, or a formula defect? If genuine, is that stock nettable against other demand? | Decides whether net requirement is understated or overstated across three-quarters of the plan. | Planning |
| 3 | **Covering `Balance to plan` (127,430 kg) exceeds total `Qty` (97,359 kg).** What does the column measure? | The covering net requirement cannot be derived until the formula is known. | Planning |
| 4 | **Three stacked daily grids** in knitting `Plan V1` (AD–DU, DW–HN, HP–LG, separated by `X` marker columns) over the same 96-day horizon. What is each? | Only one can be the machine plan; reading the wrong one silently doubles or halves load. | Planning |
| 5 | **`Liner Order` appears as a plant value** on 36 dipping lines. Real plant, order type, or data error? | Affects plant-level capacity aggregation. | Master Data |
| 6 | `Master Data.Packing Path` and `Former` are **100% empty** (0 of 1,982). Genuinely unused, or maintained elsewhere? | Packing path is needed for the packing stage; former drives dipping tooling. | Master Data |
| 7 | **Planning horizon.** Files are named for one month but span Jul–Jan. Is the plan monthly with a rolling 6-month view? | Sets the bucket count and what "late" means. | Planning |
| 8 | **Changeover matrix does not exist** in any source file. Are setup times material on knitting gauge/size changes? | `planning_rules.yaml` currently assumes 0 setup minutes — an explicit, documented assumption that will understate load if wrong. | Industrial Engineering |
| 9 | **Shift pattern and working calendar per plant.** Covering shows Day/Night; do knitting and dipping match? | Machine counts convert to hours only with a shift pattern. Knitting capacity is currently expressed in `MACHINE_DAY` for this reason. | Operations |
| 10 | **Efficiency / OEE.** Are `Receipe Times` cycle times at-standard or at-actual? | `capacity.efficiency_factor` is 1.0 pending an answer. | Industrial Engineering |

## 2. Diagnostic questions still open (non-blocking)

- Current planning process: who plans, in what sequence, what is overridden manually and why.
- SAP landscape and which extracts can be provisioned: VBAP/VBEP (demand), MARC/MARA (material),
  PLPO/MAPL (routing), CRHD/KAKO (capacity), MDBS (order), MARD/MCHB (stock).
- Which of the 13 dipping plant codes are real sites (`3G`, `5`, `7`, `3B`, `6B`, `6W`, `3W`, `FT`,
  `3B(TS)`, `3B(TS)Knuckle`, `3G(TS)`, plus `#N/A` and `Liner Order`).
- Capacity calculation method used today.
- Current scheduling method and how the daily grid is populated.
- Top three planning pain points, in the planners' own words.
- MVP success criteria and the baseline: current OTIF %, current planning cycle time.

## 3. Confirmed business rules

| Rule | Where enforced |
|---|---|
| On-time delivery is the primary objective; customer priority is the tiebreaker. | `planning_rules.yaml → objective` |
| Capacity is a hard constraint; overload is surfaced, never absorbed. | `planning_rules.yaml → capacity.allow_overload: false` |
| Unmatched cross-stage lines are flagged `UNLINKED` and planned in isolation — never dropped, never given an invented parent. | `planning_rules.yaml → unlinked_policy` |
| Available supply is counted once, from the highest-precedence source only. | `planning_rules.yaml → netting.available_supply_precedence` |
| Reserved stock is not available. | `planning_rules.yaml → netting` |

## 4. Assumptions in force

Each is a placeholder awaiting the corresponding blocking question, and is asserted by a test so it
cannot drift silently.

| Assumption | Value | Retires when |
|---|---|---|
| Changeover time | 0 minutes | Q8 answered and a matrix supplied |
| Efficiency factor on standard times | 1.0 | Q10 answered |
| Safety stock | 0 days | maintained in master data |
| Knitting capacity unit | `MACHINE_DAY`, not hours | Q9 answered |
| Covering machine capacity | null, reported critical rather than guessed | per-machine rates supplied |
| Dipping / knitting quantity unit | `UNCONFIRMED`, conversion refused | Q1 answered |

## 5. Data quality issues found

See `data/reports/exception_report.csv` after `make validate`. Headline figures from the
August 2026 workbooks, pinned by `tests/test_diagnostic_baseline.py`:

- 368 FG records with no liner code (breaks FG → SFG explosion).
- 187 covering demand lines with no confirmed delivery date (the entire covering plan).
- 5 routings with a missing or non-positive standard time.
- 2 duplicate FG codes; 0 duplicate order keys.
- 260 dipping lines missing gauge; 32 missing plant and line.
- 685 of 1,045 dipping lines carrying a liner shortage (3.66M units).
- `Master Data.Packing Path` and `Former` 100% empty; `Artwork` 96.6% `#N/A`.
- Two liner coding conventions coexisting (242 dashed vs 170 undashed) for different materials.
- Knitting `Plan V1` column Z carries the literal `1400` as its header; it holds
  `to_be_shipped − to_be_pack`. Now named `shipped_less_packed` in `sources.yaml`.

**Clean, and worth recording as such:** routing is a genuine 1:1 material→resource mapping across
all 2,555 rows — Layer 2 question 1 ("is one SFG mapped to multiple resources?") is a clean pass.
No duplicate order keys at either stage. No missing delivery dates, yarn codes or gauges on the
knitting plan.

## 6. Completed components

- Phase 1 diagnostic: all three workbooks profiled against real data.
- Join-coverage measurement; normalisation hypothesis tested and rejected.
- Phase 2: data contract (9 tables), three workbook adapters, validation engine (14 rules),
  Stage 0 join gate, exception report, 49 tests.

## 7. Not built yet, and why

Phases 3–6 (net requirements, prioritisation, multi-level explosion, rough-cut capacity, CP-SAT
scheduling, AI decision support, control tower) are specified but not implemented. The Stage 0 gate
fails on 7 of 7 links and 9 critical findings are open. A plan built on this data would be
confidently wrong.
